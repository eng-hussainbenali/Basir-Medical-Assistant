import { Medicine } from '../types';
import { speakText } from './audioService';

class ReminderService {
  private notifiedToday: Set<string> = new Set();
  private intervalId: NodeJS.Timeout | null = null;
  private onTriggerCallback: ((medicine: Medicine) => void) | null = null;

  public isSupported(): boolean {
    return typeof window !== 'undefined' && 'Notification' in window;
  }

  public getPermission(): NotificationPermission | 'unsupported' {
    if (!this.isSupported()) return 'unsupported';
    return Notification.permission;
  }

  public async requestPermission(): Promise<boolean> {
    if (!this.isSupported()) return false;
    try {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    } catch (e) {
      console.error('Failed to request notification permission:', e);
      return false;
    }
  }

  public triggerAlert(medicine: Medicine, isTest = false) {
    const title = isTest ? 'اختبار تذكير الدواء - بصير' : `تذكير بموعد الدواء: ${medicine.name}`;
    const body = `حان وقت تناول دواء ${medicine.name} (${medicine.dosage || 'حسب الجرعة المحددة'}).`;

    // 1. Voice alert via TTS for visually impaired accessibility
    const spokenMessage = isTest
      ? `هذا اختبار لتنبيه الدواء. دواء: ${medicine.name}. الجرعة: ${medicine.dosage || 'حسب التوجيهات'}.`
      : `تنبيه: حان وقت تناول دواء ${medicine.name}. الجرعة: ${medicine.dosage || 'حسب التوجيهات'}. عافاك الله.`;
    speakText(spokenMessage);

    // 2. Browser Native Notification
    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        const notif = new Notification(title, {
          body,
          icon: '/favicon.ico',
          dir: 'rtl',
          lang: 'ar',
          badge: '/favicon.ico',
          tag: `med-${medicine.id}-${new Date().toDateString()}`,
        });

        notif.onclick = () => {
          window.focus();
          notif.close();
        };
      } catch (err) {
        console.warn('Could not display system notification:', err);
      }
    }

    if (this.onTriggerCallback) {
      this.onTriggerCallback(medicine);
    }
  }

  public startChecking(
    getMedicines: () => Medicine[],
    onTrigger?: (medicine: Medicine) => void
  ) {
    if (this.intervalId) clearInterval(this.intervalId);
    if (onTrigger) this.onTriggerCallback = onTrigger;

    // Check every 20 seconds
    this.intervalId = setInterval(() => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const currentHM = `${hours}:${minutes}`;
      const dateKey = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`;

      const medicines = getMedicines();
      for (const med of medicines) {
        if (med.reminderEnabled && med.reminderTime === currentHM) {
          const reminderKey = `${med.id}_${dateKey}_${currentHM}`;
          if (!this.notifiedToday.has(reminderKey)) {
            this.notifiedToday.add(reminderKey);
            this.triggerAlert(med, false);
          }
        }
      }
    }, 20000);
  }

  public stopChecking() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }
}

export const reminderService = new ReminderService();
