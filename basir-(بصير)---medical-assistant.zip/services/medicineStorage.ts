import { collection, doc, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Medicine } from '../types';

export const subscribeUserMedicines = (
  userId: string,
  onUpdate: (meds: Medicine[]) => void,
  onError?: (err: any) => void
) => {
  const path = `users/${userId}/medicines`;
  const colRef = collection(db, 'users', userId, 'medicines');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const medicines: Medicine[] = [];
      snapshot.forEach((docSnap) => {
        medicines.push({ id: docSnap.id, ...(docSnap.data() as Omit<Medicine, 'id'>) });
      });
      onUpdate(medicines);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
      if (onError) onError(error);
    }
  );
};

export const saveMedicineToFirestore = async (userId: string, medicine: Medicine) => {
  const path = `users/${userId}/medicines/${medicine.id}`;
  const docRef = doc(db, 'users', userId, 'medicines', medicine.id);
  try {
    await setDoc(docRef, {
      userId,
      name: medicine.name,
      dosage: medicine.dosage || '',
      frequency: medicine.frequency || '',
      purpose: medicine.purpose || '',
      warning: medicine.warning || '',
      reminderTime: medicine.reminderTime || '',
      reminderEnabled: Boolean(medicine.reminderEnabled),
      createdAt: medicine.createdAt || new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
    throw error;
  }
};

export const deleteMedicineFromFirestore = async (userId: string, medicineId: string) => {
  const path = `users/${userId}/medicines/${medicineId}`;
  const docRef = doc(db, 'users', userId, 'medicines', medicineId);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
};
