let currentAudio: HTMLAudioElement | null = null;
let currentAudioUrl: string | null = null;
let currentAbortController: AbortController | null = null;
let currentPlayId = 0;
let isAudioPlaying = false;

type AudioStateListener = (isPlaying: boolean) => void;
const stateListeners = new Set<AudioStateListener>();

const notifyListeners = (playing: boolean) => {
  isAudioPlaying = playing;
  stateListeners.forEach((listener) => {
    try {
      listener(playing);
    } catch (e) {
      console.error('Error in audio state listener:', e);
    }
  });
};

export const subscribeToAudioState = (listener: AudioStateListener) => {
  stateListeners.add(listener);
  listener(isAudioPlaying);
  return () => {
    stateListeners.delete(listener);
  };
};

export const getIsAudioPlaying = () => isAudioPlaying;

/**
 * Immediately terminates any ongoing audio, in-flight TTS network requests,
 * and browser speech synthesis. Prevents any overlapping voice streams.
 */
export const stopAudio = () => {
  currentPlayId++;

  // 1. Abort any active TTS fetch requests
  if (currentAbortController) {
    try {
      currentAbortController.abort();
    } catch (e) {
      // ignore
    }
    currentAbortController = null;
  }

  // 2. Stop and clear any playing HTMLAudioElement and release object URL
  if (currentAudio) {
    try {
      currentAudio.pause();
      currentAudio.onended = null;
      currentAudio.onerror = null;
      currentAudio.currentTime = 0;
      currentAudio.removeAttribute('src');
      currentAudio.load();
    } catch (e) {
      // ignore
    }
    currentAudio = null;
  }

  if (currentAudioUrl) {
    try {
      URL.revokeObjectURL(currentAudioUrl);
    } catch (e) {
      // ignore
    }
    currentAudioUrl = null;
  }

  // 3. Cancel browser speech synthesis
  if (typeof window !== 'undefined' && window.speechSynthesis) {
    try {
      window.speechSynthesis.cancel();
      // Double cancel for mobile browsers quirks
      if (window.speechSynthesis.speaking || window.speechSynthesis.pending) {
        window.speechSynthesis.cancel();
      }
    } catch (e) {
      // ignore
    }
  }

  notifyListeners(false);
};

/**
 * Fallback browser speech synthesis tuned with Saudi accent preferences
 */
const nativeSpeak = (text: string, playId: number) => {
  if (typeof window === 'undefined' || !window.speechSynthesis) {
    notifyListeners(false);
    return;
  }

  if (playId !== currentPlayId) {
    return;
  }

  try {
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ar-SA';

    // Search for best Saudi Arabic voice
    const voices = window.speechSynthesis.getVoices();
    const saudiVoice =
      voices.find(
        (v) =>
          (v.lang === 'ar-SA' || v.lang.replace('_', '-').toLowerCase() === 'ar-sa') &&
          (v.name.toLowerCase().includes('saudi') ||
            v.name.toLowerCase().includes('natural') ||
            v.name.toLowerCase().includes('online') ||
            v.name.includes('نايف') ||
            v.name.includes('ماجد') ||
            v.name.includes('سلمى') ||
            v.name.includes('طارق'))
      ) ||
      voices.find((v) => v.lang === 'ar-SA' || v.lang.replace('_', '-').toLowerCase() === 'ar-sa') ||
      voices.find((v) => v.lang.startsWith('ar'));

    if (saudiVoice) {
      utterance.voice = saudiVoice;
    }

    // Natural, calm human pace for visually impaired listeners
    utterance.rate = 0.93;
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      if (playId === currentPlayId) {
        notifyListeners(true);
      } else {
        window.speechSynthesis.cancel();
      }
    };

    utterance.onend = () => {
      if (playId === currentPlayId) {
        notifyListeners(false);
      }
    };

    utterance.onerror = () => {
      if (playId === currentPlayId) {
        notifyListeners(false);
      }
    };

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Browser speech error:', err);
    notifyListeners(false);
  }
};

/**
 * Speaks the provided text using high-fidelity Saudi Gemini TTS with instant overlap prevention.
 */
export const speakText = async (text: string) => {
  if (!text || !text.trim()) return;

  // 1. Immediately cancel ANY prior sound or speech
  stopAudio();

  const playId = currentPlayId;
  const abortController = new AbortController();
  currentAbortController = abortController;

  notifyListeners(true);

  // If this is the main intro, play the pre-rendered 24kHz Saudi intro audio with 0ms lag
  if (text.trim().startsWith('يا هلا فيك في تطبيق بصير')) {
    try {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }

      const introAudio = new Audio('/audio/intro.wav');
      introAudio.preload = 'auto';
      currentAudio = introAudio;

      const cleanupIntro = () => {
        if (currentAudio === introAudio) {
          currentAudio = null;
        }
        if (playId === currentPlayId) {
          notifyListeners(false);
        }
      };

      introAudio.onended = cleanupIntro;
      introAudio.onerror = () => {
        cleanupIntro();
        nativeSpeak(text, playId);
      };

      await introAudio.play();
      return;
    } catch {
      // If browser autoplay policy or static audio issue, proceed with standard flow
    }
  }

  try {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
      signal: abortController.signal,
    });

    if (!res.ok) {
      throw new Error(`TTS server returned status ${res.status}`);
    }

    const data = await res.json();

    // If stopped or superseded during network latency, abort playback immediately
    if (playId !== currentPlayId || abortController.signal.aborted) {
      return;
    }

    if (!data.audio) {
      throw new Error('No audio returned from server');
    }

    // Before starting HTML Audio, ensure speech synthesis is dead silent
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }

    // Decode base64 to binary buffer and create high-efficiency Blob URL
    const binaryStr = window.atob(data.audio);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
    const audioUrl = URL.createObjectURL(blob);
    currentAudioUrl = audioUrl;

    const audio = new Audio(audioUrl);
    audio.preload = 'auto';
    currentAudio = audio;

    const cleanupAudio = () => {
      if (currentAudio === audio) {
        currentAudio = null;
      }
      if (currentAudioUrl === audioUrl) {
        URL.revokeObjectURL(audioUrl);
        currentAudioUrl = null;
      }
      if (playId === currentPlayId) {
        notifyListeners(false);
      }
    };

    audio.onended = cleanupAudio;
    audio.onerror = () => {
      cleanupAudio();
    };

    await audio.play();
  } catch (err: any) {
    // If user cancelled, navigated, or clicked another action, do nothing
    if (err.name === 'AbortError' || playId !== currentPlayId) {
      return;
    }

    // Smooth fallback to Saudi browser voice
    nativeSpeak(text, playId);
  }
};
