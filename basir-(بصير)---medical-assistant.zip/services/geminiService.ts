import { Medicine, AnalysisResult } from "../types";

export const analyzeMedicineImage = async (
  base64Image: string,
  currentMedicines: Medicine[]
): Promise<AnalysisResult> => {
  const response = await fetch('/api/analyze-medicine', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      base64Image,
      currentMedicines,
    }),
  });

  const text = await response.text();
  let parsed: any = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error(
      response.ok
        ? 'استجابة غير صالحة من خدمة فحص الدواء'
        : `خطأ في الاتصال بالخادم (${response.status})`
    );
  }

  if (!response.ok) {
    throw new Error(parsed?.error || `Server error: ${response.status}`);
  }

  return parsed as AnalysisResult;
};

export const chatWithAI = async (
  message: string,
  currentMedicines: Medicine[],
  _history: { role: string; text: string }[] = []
): Promise<string> => {
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      message,
      currentMedicines,
    }),
  });

  const text = await response.text();
  let parsed: any = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error(
      response.ok
        ? 'استجابة غير صالحة من المساعد الصيدلي'
        : `خطأ في الاتصال بالخادم (${response.status})`
    );
  }

  if (!response.ok) {
    throw new Error(parsed?.error || `Server error: ${response.status}`);
  }

  return parsed.reply || '';
};
