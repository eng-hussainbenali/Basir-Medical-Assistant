import React from 'react';

interface BasirLogoProps {
  className?: string;
  variant?: 'full' | 'icon';
  size?: number;
}

export const BasirLogo: React.FC<BasirLogoProps> = ({
  className = 'w-10 h-10',
  variant = 'icon',
}) => {
  if (variant === 'icon') {
    return (
      <svg
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
        aria-label="شعار بصير"
      >
        {/* Soft rounded container background */}
        <rect width="200" height="200" rx="44" fill="#ffffff" />

        {/* Capsule Container */}
        <g transform="translate(18, 20) scale(0.82)">
          {/* Left Pill Half (Navy Blue) */}
          <path
            d="M 52 20 
               A 45 45 0 0 0 7 65 
               L 7 135 
               A 45 45 0 0 0 52 180 
               L 98 180 
               L 98 20 
               Z"
            fill="#0d284d"
          />

          {/* Right Pill Half (Sky Cyan Blue) */}
          <path
            d="M 102 20 
               L 148 20 
               A 45 45 0 0 1 193 65 
               L 193 135 
               A 45 45 0 0 1 148 180 
               L 102 180 
               Z"
            fill="#56bbf1"
          />

          {/* Center Soundwave & Pulse Wave (White) */}
          {/* Left entry line with notch */}
          <path
            d="M 7 100 L 62 100 C 66 100 68 93 72 93 C 76 93 78 107 82 107 C 85 107 86 100 90 100"
            stroke="#ffffff"
            strokeWidth="5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Audio Equalizer Frequency Bars */}
          {/* Bar 1 */}
          <rect x="73" y="86" width="5.5" height="28" rx="2.75" fill="#ffffff" />
          {/* Bar 2 */}
          <rect x="83" y="72" width="5.5" height="56" rx="2.75" fill="#ffffff" />
          {/* Bar 3 (Center highest) */}
          <rect x="97.25" y="60" width="5.5" height="80" rx="2.75" fill="#ffffff" />
          {/* Bar 4 */}
          <rect x="111.5" y="72" width="5.5" height="56" rx="2.75" fill="#ffffff" />
          {/* Bar 5 */}
          <rect x="121.5" y="86" width="5.5" height="28" rx="2.75" fill="#ffffff" />

          {/* Right Heartbeat Wave exiting right */}
          <path
            d="M 110 100 L 128 100 C 132 100 134 94 137 94 C 141 94 144 112 147 112 C 150 112 153 100 156 100 L 193 100"
            stroke="#ffffff"
            strokeWidth="5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      </svg>
    );
  }

  // Full Variant with Typography "بصير"
  return (
    <svg
      viewBox="0 0 260 300"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="شعار بصير الكامل"
    >
      {/* Background card */}
      <rect width="260" height="300" rx="36" fill="#ffffff" />

      {/* Capsule Container */}
      <g transform="translate(30, 20) scale(1)">
        {/* Left Pill Half (Navy Blue) */}
        <path
          d="M 52 20 
             A 45 45 0 0 0 7 65 
             L 7 135 
             A 45 45 0 0 0 52 180 
             L 98 180 
             L 98 20 
             Z"
          fill="#0d284d"
        />

        {/* Right Pill Half (Sky Cyan Blue) */}
        <path
          d="M 102 20 
             L 148 20 
             A 45 45 0 0 1 193 65 
             L 193 135 
             A 45 45 0 0 1 148 180 
             L 102 180 
             Z"
          fill="#56bbf1"
        />

        {/* Soundwave lines */}
        <path
          d="M 7 100 L 62 100 C 66 100 68 93 72 93 C 76 93 78 107 82 107 C 85 107 86 100 90 100"
          stroke="#ffffff"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        <rect x="73" y="86" width="5.5" height="28" rx="2.75" fill="#ffffff" />
        <rect x="83" y="72" width="5.5" height="56" rx="2.75" fill="#ffffff" />
        <rect x="97.25" y="60" width="5.5" height="80" rx="2.75" fill="#ffffff" />
        <rect x="111.5" y="72" width="5.5" height="56" rx="2.75" fill="#ffffff" />
        <rect x="121.5" y="86" width="5.5" height="28" rx="2.75" fill="#ffffff" />

        <path
          d="M 110 100 L 128 100 C 132 100 134 94 137 94 C 141 94 144 112 147 112 C 150 112 153 100 156 100 L 193 100"
          stroke="#ffffff"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>

      {/* Typography: بصير in exact stylized Kufic/Modern Arabic brand font */}
      <g transform="translate(130, 255)">
        <text
          x="0"
          y="0"
          textAnchor="middle"
          fill="#0d284d"
          style={{
            fontFamily: "'Tajawal', 'Cairo', 'Segoe UI', system-ui, sans-serif",
            fontWeight: 900,
            fontSize: '56px',
            letterSpacing: '1px',
          }}
        >
          بَصير
        </text>
      </g>
    </svg>
  );
};
