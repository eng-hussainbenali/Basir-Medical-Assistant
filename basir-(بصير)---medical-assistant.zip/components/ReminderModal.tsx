import React, { useState } from 'react';
import { Medicine } from '../types';
import { reminderService } from '../services/reminderService';
import { speakText, stopAudio } from '../services/audioService';

interface ReminderModalProps {
  medicine: Medicine;
  onClose: () => void;
  onSave: (updatedMedicine: Medicine) => Promise<void>;
}

const PRESET_TIMES = [
  { label: 'الصباح (08:00 ص)', time: '08:00' },
  { label: 'الظهيرة (01:00 م)', time: '13:00' },
  { label: 'المساء (07:00 م)', time: '19:00' },
  { label: 'قبل النوم (10:00 م)', time: '22:00' },
];

export const ReminderModal: React.FC<ReminderModalProps> = ({
  medicine,
  onClose,
  onSave,
}) => {
  const [reminderTime, setReminderTime] = useState(medicine.reminderTime || '08:00');
  const [reminderEnabled, setReminderEnabled] = useState(
    medicine.reminderEnabled !== undefined ? medicine.reminderEnabled : true
  );
  const [isSaving, setIsSaving] = useState(false);

  const handleTestNotification = async () => {
    // Request permission first if not granted
    if (reminderService.getPermission() !== 'granted') {
      const granted = await reminderService.requestPermission();
      if (!granted) {
        speakText('يرجى السماح بالإشعارات من إعدادات المتصفح لظهور التنبيه.');
      }
    }

    reminderService.triggerAlert(
      {
        ...medicine,
        reminderTime,
        reminderEnabled: true,
      },
      true
    );
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      if (reminderEnabled && reminderService.getPermission() !== 'granted') {
        await reminderService.requestPermission();
      }

      const updated: Medicine = {
        ...medicine,
        reminderTime,
        reminderEnabled,
      };

      await onSave(updated);

      if (reminderEnabled) {
        speakText(`تم تفعيل التنبيه اليومي لدواء ${medicine.name} في تمام الساعة ${reminderTime}.`);
      } else {
        speakText(`تم إيقاف التنبيه لدواء ${medicine.name}.`);
      }

      onClose();
    } catch (err) {
      console.error('Failed to save reminder:', err);
      speakText('حدث خطأ أثناء حفظ التذكير.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border-2 border-indigo-100 flex flex-col gap-5 text-right animate-in fade-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl">⏰</span>
            <h3 id="modal-title" className="text-xl font-extrabold text-indigo-950">
              تذكير يومي: {medicine.name}
            </h3>
          </div>
          <button
            onClick={() => {
              stopAudio();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold"
            aria-label="إغلاق النافذة"
          >
            ✕
          </button>
        </div>

        {/* Toggle Enabled */}
        <div className="bg-slate-50 p-4 rounded-2xl flex items-center justify-between border border-slate-200">
          <div>
            <span className="font-bold text-slate-900 block text-base">تفعيل التنبيه اليومي</span>
            <span className="text-xs text-slate-500">إشعار بالصوت والشاشة في الموعد المحدد</span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={reminderEnabled}
              onChange={(e) => setReminderEnabled(e.target.checked)}
              className="sr-only peer"
              aria-label="تفعيل أو تعطيل التنبيه"
            />
            <div className="w-13 h-7 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>

        {/* Time Input */}
        <div className="space-y-2">
          <label htmlFor="reminder-time-input" className="block text-sm font-bold text-slate-700">
            وقت التنبيه (توقيت 24 ساعة):
          </label>
          <input
            id="reminder-time-input"
            type="time"
            value={reminderTime}
            onChange={(e) => setReminderTime(e.target.value)}
            disabled={!reminderEnabled}
            className="w-full text-center text-3xl font-extrabold tracking-wider p-3 bg-indigo-50 border-2 border-indigo-200 rounded-2xl text-indigo-950 focus:border-indigo-600 focus:outline-none disabled:opacity-40"
          />
        </div>

        {/* Preset quick times */}
        <div className="space-y-1.5">
          <span className="text-xs font-semibold text-slate-500 block">أوقات شائعة سريعة:</span>
          <div className="grid grid-cols-2 gap-2">
            {PRESET_TIMES.map((preset) => (
              <button
                key={preset.time}
                type="button"
                onClick={() => setReminderTime(preset.time)}
                disabled={!reminderEnabled}
                className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all ${
                  reminderTime === preset.time
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                } disabled:opacity-40`}
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Test alert button */}
        <div className="pt-1">
          <button
            type="button"
            onClick={handleTestNotification}
            className="w-full py-2.5 px-4 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 font-bold rounded-2xl text-sm flex items-center justify-center gap-2 transition-colors"
          >
            <span>🔔</span>
            <span>تجربة التنبيه والصوت الآن</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="flex-1 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl shadow-lg transition-all text-base active:scale-95 disabled:opacity-50"
          >
            {isSaving ? 'جاري الحفظ...' : 'حفظ موعد التذكير'}
          </button>
          <button
            type="button"
            onClick={() => {
              stopAudio();
              onClose();
            }}
            className="px-5 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-base transition-colors"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};
