import React, { useState, useEffect } from 'react';
import { AppView } from '../types';
import { User } from 'firebase/auth';
import { stopAudio, subscribeToAudioState } from '../services/audioService';
import { BasirLogo } from './BasirLogo';

interface LayoutProps {
  children: React.ReactNode;
  currentView: AppView;
  setView: (view: AppView) => void;
  user: User | null;
  onSignIn: () => void;
  onSignOut: () => void;
  notificationPermission: NotificationPermission | 'unsupported';
  onRequestNotificationPermission: () => void;
}

const Layout: React.FC<LayoutProps> = ({
  children,
  currentView,
  setView,
  user,
  onSignIn,
  onSignOut,
  notificationPermission,
  onRequestNotificationPermission,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToAudioState((playing) => {
      setIsPlayingAudio(playing);
    });
    return unsubscribe;
  }, []);

  const handleNavChange = (view: AppView) => {
    stopAudio();
    setView(view);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans" dir="rtl">
      {/* Header */}
      <header className="bg-indigo-700 text-white shadow-lg p-3 md:p-4 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto flex justify-between items-center gap-2">
          {/* Logo & Brand Name */}
          <button
            onClick={() => handleNavChange(AppView.SCANNER)}
            className="flex items-center gap-3 text-right group focus:outline-none"
            aria-label="الرئيسية - بصير"
          >
            <div className="relative">
              <BasirLogo className="w-11 h-11 rounded-2xl shadow-md overflow-hidden bg-white p-0.5 transform group-hover:scale-105 transition-transform" variant="icon" />
              {isPlayingAudio && (
                <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-indigo-700"></span>
                </span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-2xl font-extrabold tracking-tight">بَصير</h1>
                <span className="text-[10px] bg-indigo-500/80 text-indigo-100 font-bold px-1.5 py-0.5 rounded-md">
                  صوت سعودي
                </span>
              </div>
              <p className="text-xs text-indigo-200">مساعدك الطبي الذكي</p>
            </div>
          </button>

          {/* Action Header Controls */}
          <div className="flex items-center gap-2">
            {/* Live Audio Stop / Playback Status Button */}
            {isPlayingAudio ? (
              <button
                onClick={() => stopAudio()}
                className="text-xs bg-red-600 hover:bg-red-700 text-white font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-red-300 shadow-md animate-pulse transition-all"
                title="إيقاف الصوت الجاري فوراً"
                aria-label="إيقاف الصوت الجاري فوراً"
              >
                <span className="inline-block w-2.5 h-2.5 bg-white rounded-xs"></span>
                <span>إيقاف الصوت</span>
              </button>
            ) : (
              <button
                onClick={() => stopAudio()}
                className="text-xs bg-indigo-900/80 hover:bg-indigo-950 text-indigo-100 font-medium px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-indigo-400/30 transition-colors shadow-sm"
                title="كتم الصوت فوراً"
                aria-label="كتم الصوت"
              >
                <span>🔇</span>
                <span className="hidden sm:inline">كتم الصوت</span>
              </button>
            )}

            {/* Notification permission button */}
            {notificationPermission !== 'granted' && notificationPermission !== 'unsupported' && (
              <button
                onClick={() => {
                  stopAudio();
                  onRequestNotificationPermission();
                }}
                className="text-xs bg-amber-400 hover:bg-amber-500 text-amber-950 font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 transition-colors shadow-sm"
                title="تفعيل إشعارات التنبيه بمواعيد الدواء"
                aria-label="تفعيل إشعارات التنبيه بمواعيد الدواء"
              >
                <span>🔔</span>
                <span className="hidden sm:inline">تفعيل التنبيهات</span>
              </button>
            )}

            {notificationPermission === 'granted' && (
              <span
                className="text-xs bg-emerald-600 text-white px-2.5 py-1 rounded-full flex items-center gap-1 font-medium"
                title="التنبيهات اليومية مفعلة"
              >
                <span>🔔</span>
                <span className="hidden md:inline">التنبيهات مفعلة</span>
              </span>
            )}

            {/* Auth Section */}
            {user ? (
              <div className="flex items-center gap-2 bg-indigo-800/80 p-1.5 rounded-2xl border border-indigo-500/40">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'المستخدم'}
                    className="w-7 h-7 rounded-full border border-white/50"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center text-xs font-bold text-white">
                    {user.email?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}
                <span className="text-xs max-w-[90px] truncate hidden sm:inline text-indigo-100">
                  {user.displayName || user.email?.split('@')[0]}
                </span>
                <button
                  onClick={() => {
                    stopAudio();
                    onSignOut();
                  }}
                  className="text-xs bg-indigo-900/90 hover:bg-red-600/90 px-2 py-1 rounded-xl text-white font-medium transition-colors"
                  aria-label="تسجيل الخروج"
                >
                  خروج
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  stopAudio();
                  onSignIn();
                }}
                className="text-xs bg-white text-indigo-800 hover:bg-indigo-50 font-bold px-3 py-1.5 rounded-xl transition-all shadow-sm flex items-center gap-1.5"
                aria-label="تسجيل الدخول باستخدام Google"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>دخول</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 p-4 md:p-8 max-w-4xl mx-auto w-full pb-32">
        {children}
      </main>

      {/* Floating Audio Bar if Speaking */}
      {isPlayingAudio && (
        <div className="fixed bottom-20 left-4 right-4 md:left-auto md:right-8 md:w-96 z-40 animate-bounce">
          <div className="bg-slate-900/95 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center justify-between border border-slate-700 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              <p className="text-xs font-semibold text-emerald-300">جاري التحدث بصوت سعودي...</p>
            </div>
            <button
              onClick={() => stopAudio()}
              className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold transition-colors"
            >
              إيقاف الصوت ✕
            </button>
          </div>
        </div>
      )}

      {/* Navigation Bar (Sticky with zero overlap on view change) */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around p-3 shadow-[0_-4px_10px_rgba(0,0,0,0.05)] z-50">
        <NavButton
          active={currentView === AppView.SCANNER}
          onClick={() => handleNavChange(AppView.SCANNER)}
          label="فحص الدواء"
          icon={<CameraIcon />}
        />
        <NavButton
          active={currentView === AppView.PROFILE}
          onClick={() => handleNavChange(AppView.PROFILE)}
          label="ملفي الطبي"
          icon={<ProfileIcon />}
        />
        <NavButton
          active={currentView === AppView.CHAT}
          onClick={() => handleNavChange(AppView.CHAT)}
          label="استشارة"
          icon={<ChatIcon />}
        />
      </nav>
    </div>
  );
};

const NavButton: React.FC<{ active: boolean; onClick: () => void; label: string; icon: React.ReactNode }> = ({
  active,
  onClick,
  label,
  icon,
}) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center gap-1 flex-1 py-2 transition-all rounded-xl ${
      active ? 'text-indigo-700 font-bold bg-indigo-50' : 'text-slate-500 hover:bg-slate-50'
    }`}
    aria-label={label}
  >
    <div className={`w-6 h-6 ${active ? 'scale-110' : ''}`}>{icon}</div>
    <span className="text-xs mt-1">{label}</span>
  </button>
);

const CameraIcon = () => (
  <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"
    />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

const ProfileIcon = () => (
  <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"
    />
  </svg>
);

const ChatIcon = () => (
  <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
    />
  </svg>
);

export default Layout;
